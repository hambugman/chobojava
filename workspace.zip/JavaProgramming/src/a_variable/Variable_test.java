package a_variable;

public class Variable_test {

	public static void main(String[] args) {
		//9가지 데이터타입을 사용해 9개의 변수를 선언해주세요. (byte,short,int,long,float,double,char,string,boolean)
		
		//위에서 선안한 9개의 변수들을 초기화 해주세요 
		
		//변수 3개를 선언해 변수의 타입과 다른 타입의 값으로 초기화해주세요.
		
		//자신의 이름을 저장할 변수를 선언하고 Scanner를 사용해 이름을 저장해주세요.
		
		//자신의 나이를 저장할 변수를 선언하고 Scanner를 사용해 이름을 저장해주세요.
		
		//이름과 나이를 출력해주세요

	}

}
