package j_collection;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import e_oop.ScanUtil;

public class Board {
	
	Date date = new Date()	;				//날짜 date로 초기화
	SimpleDateFormat writeday= new SimpleDateFormat("yyyy년-MM월-dd일");
	
	
	HashMap<String, Object> write = new HashMap<String,Object>();	//글내용이 담긴 해시맵
	ArrayList<HashMap<String,Object>>writes = new ArrayList<HashMap<String,Object>>();
	
	public static void main(String[] args) {	//메인메서드
		new Board().Menu();
	}
							
//		 * 목록에서는 조회, 등록, 종료
//		 * 상세화면에서는 수정, 삭제, 목록

		
//-------------------------------게시판 메뉴 -----------------------------------------
		void Menu(){
			while(true){
				System.out.println("-------------------------------");
				System.out.println("No\t제목\t작성자\t작성일");
				System.out.println("===============================");
				System.out.println(write);
				System.out.println("-------------------------------");
				for(int i = 0; i < writes.size(); i++){			//글순서를 위해 -1을 넣음
					System.out.print(writes.get(i).get("No"));
					System.out.print("\t"+writes.get(i).get("제목"));
					System.out.print("\t"+writes.get(i).get("작성자"));
					System.out.print("\t"+writes.get(i).get("작성일"));
					System.out.println();
					}
				System.out.print("1.조회	  2.등록	   3.종료");
				int input =0;
				input = ScanUtil.nextInt();
				switch(input){
				case 1:
					System.out.println("조회");	
					Search();
					break;
				case 2:
					System.out.println("등록");
					Write();
					break;
				case 3:	
					System.out.println("종료");//종료문
					System.out.println(4);	
					}	
				}//while
			}//Menu
//-------------------------------출력 메서드-------------------------------------------
	void index(){
			
		
		
		
	}
		
		
//-------------------------------글 등록 메서드------------------------------------------
		
//		등록시 작성자 제목 내용이 입력되어야한다. 글 번호도 매겨야함. 1씩 증가		
	void Write(){
		HashMap<St, Object> board = new HashMap<>();				//새로운 hash맵을 넣어야 저장됨
		System.out.println("제목");		//작성자:Writer 제목:Title 내용:Content
			String Title = ScanUtil.nextLine();
		System.out.println("작성자");
			String Writer = ScanUtil.nextLine();
		int No = 1;	
			write.put("제목",Title);//작성번호
			write.put("작성자",Writer);
			write.put("작성일",new Date());//작성일
			write.put("No", No++);	
			write.add(board);
			
			
		}
		
//-----------------------------수정 메서드----------------------------------------------
	void Fix(){
			System.out.println("몇번째 글을 수정하시겠습니까?");
			int input = 0;
			input = ScanUtil.nextInt();
			}
		
	
		
		

	
//----------------------------삭제 메서드-----------------------------------------------
	void Delete(){
			System.out.println("몇번째 글을 삭제하시겠습니까?");
			int input = 0;
			input = ScanUtil.nextInt();
			}
		
	
//--------------------------상세 조회 메서드----------------------------------------------	
	void Search(){
		
	}
//	System.out.println("내용");				내용입력.
//	String Content = ScanUtil.nextLine();
//	write.put("내용",Content);

	public void start() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}//최종 메서드

