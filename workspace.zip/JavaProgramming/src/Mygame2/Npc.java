package Mygame2;

public class Npc  {
	
	void begger(){
		
	}
	
	
	void Dog(){
			
	}
	
	
	void Thief(){
		
	}
	
	
}
