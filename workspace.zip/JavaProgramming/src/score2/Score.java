package score2;

public class Score {
	public static void main(String[] args){
		
		String[] studentName = 
				{ "강나영", "강동환", "강태영", "곽지훈", "김서윤"
				, "김영훈", "김진석", "김충신", "박슬기", "박채린"
				, "손영태", "손영흔", "안정연", "이선우", "이수보"
				, "이주홍", "이중호", "임현정", "장유진", "정신애"
				, "조수경", "조하영", "조혜민", "허민정", "박지은"};
		
		Student[] students = new Student[studentName.length];
		
		//합계, 평균
		
		//석차
		
		//석차순 정렬
		
		//과목별 합계,평균
		
		//출력
		
		
		
		
		

	}
}
