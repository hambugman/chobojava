package score2;

public class Student {
	
	
	
	
	int kor = (int)(Math.random()*101);
	int eng = (int)(Math.random()*101);
	int math = (int)(Math.random()*101);
	
	void(namesum=kor+eng+math;){
		
		
	}
	
	
	
	
	
}
