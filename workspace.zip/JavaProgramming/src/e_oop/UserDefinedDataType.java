package e_oop;

public class UserDefinedDataType {

	public static void main(String[] args) {
			/*
			 * 사용자 정의 데이터 타입
			 * - 데이터의 최종 진화 형태이다. (기본형 -> 배열 -> 클래스)
			 * - 서로 다른 타입의 데이터를 묶어서 사용하는 것이다.
			 * - 변수와 메서드로 구성할 수 있다. 변수는 데이터 메서드는 그것으로 무엇을 하게끔 만드는 기능
			 */
		
		//기본형
		int kor;
		int eng;
		int math;
		int sum;
		double avg;
		
		
		//배열
		int[]scores;
		int sum2;
		double avg2;
		
		//클래스
		Student student = new Student();	//클래스의 변수와 초기화방법
		/*
		 * student(변수) = 100번지(주소)
		 * 
		 * 100번지
		 * Student{
		 * kor, eng, math, sum, avg, name	// ->(객체/인스턴스)
		 * }
		 */
		
		student.kor = 80;
		student.eng = 90;
		student.math = 70;
		student.sum = student.kor+student.eng+student.math;
		student.avg = student.sum/3.0;
		student.name = "홍길동";
		
		System.out.println(student.name+"의 합계 : "+student.sum+"\n  평균:  "+student.avg);
		
		
		
		
		
	}

}

class Student{
	int kor;
	int eng;
	int math;
	int sum;
	double avg;
	String name;
}