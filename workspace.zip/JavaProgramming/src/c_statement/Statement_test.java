package c_statement;

public class Statement_test {

	public static void main(String[] args) {
		//조건문
		//숫자를 입력받아 그 숫자가 0인지 0이 아닌지 출력해주세요.
		
		
		// 1~100 사이의 랜덤한 수를 3개 발생시키고 오름차순으로 출력해주세요.
		
		
		//반복문
		//1부터 100까지 짝수의 합을 출력해주세요
		
		//구구단 9단을 출력해보세요

		//구구단 2단부터 9단까지
		
		//구구단 2단부터 9단까지 가로 출력

	}

}
