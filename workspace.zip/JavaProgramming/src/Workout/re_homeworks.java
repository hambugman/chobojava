package Workout;

import java.util.Scanner;

public class re_homeworks {

	public static void main(String[] args) {

		
		
		
		
		
	}
	
}
