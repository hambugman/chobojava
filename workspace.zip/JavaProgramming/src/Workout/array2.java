package Workout;

public class array2 {
	
	public static void main(String[] args) {
		
		
		
		
		
	}

}
